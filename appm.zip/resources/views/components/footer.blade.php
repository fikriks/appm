<div class="footer-left">
    Copyright &copy; {{ date('Y') }} <div class="bullet"></div> Created By <a href="https://facebook.com/fkhairulshaleh2" target="blank">Fikri Khairul Shaleh</a>
  </div>
  <div class="footer-right">
      <small>V 1.0.0</small>
  </div>
