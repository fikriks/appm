<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
      <a href="<?php if(Auth::guard('web')->check()): ?> <?php echo e(route('admin.dashboard')); ?> <?php else: ?> <?php echo e(route('masyarakat.dashboard')); ?> <?php endif; ?>">APPM</a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
      <a href="<?php if(Auth::guard('web')->check()): ?> <?php echo e(route('admin.dashboard')); ?> <?php else: ?> <?php echo e(route('masyarakat.dashboard')); ?> <?php endif; ?>">APPM</a>
    </div>
    <ul class="sidebar-menu">
      <li class="menu-header">Dashboard</li>
      <li class="nav-item <?php if(request()->is(request()->segment(2) == 'dashboard')): ?> active <?php endif; ?>"><a href="<?php if(Auth::guard('web')->check()): ?> <?php echo e(route('admin.dashboard')); ?> <?php else: ?> <?php echo e(route('masyarakat.dashboard')); ?> <?php endif; ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a></li>
      <li class="menu-header">Pengaduan</li>
      <li class="nav-item <?php if(request()->is( request()->segment(2) == 'pengaduan')): ?> active <?php elseif(request()->is('*/pengaduan/*')): ?> active <?php endif; ?>"><a href="<?php if(Auth::guard('web')->check()): ?> <?php echo e(route('admin.pengaduan')); ?> <?php else: ?> <?php echo e(route('masyarakat.pengaduan')); ?> <?php endif; ?>" class="nav-link"><i class="fas fa-suitcase"></i><span>Pengaduan
        <?php if(auth()->check() && auth()->user()->hasRole('admin|petugas')): ?>
        <p class="badge badge-danger"><?php echo e(count(\App\Models\Pengaduan::ditinjau()->get())); ?></p>
        <?php endif; ?>
        </span></a></li>
      <?php if(auth()->check() && auth()->user()->hasRole('admin|petugas')): ?>
      <li class="menu-header">Tanggapan</li>
      <li class="nav-item <?php if(request()->is( request()->segment(2) == 'tanggapan')): ?> active <?php elseif(request()->is('*/tanggapan/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.tanggapan')); ?>" class="nav-link"><i class="fas fa-gavel"></i><span>Tanggapan</span></a></li>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
      <li class="menu-header">Petugas & Masyarakat</li>
      <li class="nav-item <?php if(request()->is( request()->segment(2) == 'masyarakat')): ?> active <?php elseif(request()->is('*/masyarakat/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.masyarakat')); ?>" class="nav-link"><i class="fas fa-users-cog"></i><span>Masyarakat</span></a></li>
      <li class="nav-item <?php if(request()->is( request()->segment(2) == 'petugas')): ?> active <?php elseif(request()->is('*/petugas/*')): ?> active <?php endif; ?>"><a href="<?php echo e(route('admin.petugas')); ?>" class="nav-link"><i class="fas fa-users"></i><span>Petugas</span></a></li>
    <?php endif; ?>
    </ul>
 </aside>
<?php /**PATH D:\Project\appm\resources\views/components/sidebar.blade.php ENDPATH**/ ?>