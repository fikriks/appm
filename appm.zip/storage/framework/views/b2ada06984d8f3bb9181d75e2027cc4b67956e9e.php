<?php $__env->startSection('title','Tanggapan'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Tanggapan</h1>
            <div class="section-header-breadcrumb">
                <?php echo e(Breadcrumbs::render('admin.tanggapan')); ?>

            </div>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="text-primary">Tanggapan
                                <span>(<?php echo e($tanggapan->total()); ?>)</span>
                                <a href="<?php echo e(route('admin.tanggapan.create')); ?>" class="btn btn-primary">Tambah <i class="fas fa-plus"></i></a>
                                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                <a href="<?php echo e(route('admin.tanggapan.pdf')); ?>" class="btn btn-danger">Cetak PDF <i class="fas fa-newspaper"></i></a>
                                <?php endif; ?>
                            </h4>
                            <div class="card-header-form">
                                <form action=<?php echo e(route(request()->route()->getName())); ?>>
                                    <div class="input-group">
                                      <input type="text" class="form-control" placeholder="Cari" name="cari" value="<?php echo e(request()->get('search')); ?>">
                                      <div class="input-group-btn">
                                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                      </div>
                                    </div>
                                  </form>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive table-invoice">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Tanggal Tanggapan</th>
                                            <th>Judul Pengaduan</th>
                                            <th>Tanggapan</th>
                                            <th>Yang Menanggapi</th>
                                            <th>Diedit</th>
                                            <th>Aksi</th>
                                        </tr>
                                     </thead>
                                        <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $tanggapan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e(\Carbon\Carbon::parse($t->tgl_tanggapan)->isoFormat('DD MMMM Y')); ?></td>
                                            <td><?php echo e($t->pengaduan->judul_laporan); ?></td>
                                            <td><?php echo e($t->tanggapan); ?></td>
                                            <td><?php echo e($t->petugas->nama_petugas); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($t->updated_at)->isoFormat('DD MMMM Y')); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.tanggapan.show',['tanggapan' => $t])); ?>" class="btn btn-success"><i class="fa fa-eye"></i></a>
                                                <a href="<?php echo e(route('admin.tanggapan.edit',['tanggapan' => $t])); ?>" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                                <?php if(!$t->pengaduan->status == 'selesai'): ?>
                                                    <button class="btn btn-danger delete-confirm" data-action="<?php echo e(route('admin.tanggapan.destroy',$t)); ?>"><i class="fa fa-trash"></i></button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr class="text-center">
                                            <td colspan="6">Tidak Ada Data</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="paginate">
                                <?php echo e($tanggapan->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\appm\resources\views/admin/tanggapan/index.blade.php ENDPATH**/ ?>