<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
<title><?php echo $__env->yieldContent('title'); ?> &mdash; APPM</title>
<meta name="description" content="APPM">
<link rel="shortcut icon" href="favicon.ico">

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/modules/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/modules/fontawesome/css/all.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/modules/select2/dist/css/select2.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/components.min.css')); ?>">
<?php echo $__env->yieldPushContent('styles'); ?>
<?php /**PATH D:\Project\appm\resources\views/components/head.blade.php ENDPATH**/ ?>