<?php $__env->startSection('title','Detail Pengaduan '.$pengaduan->judul_laporan); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Detail Pengaduan</h1>
        <div class="section-header-breadcrumb">
            <?php if(!auth()->check() || ! auth()->user()->hasRole('admin|petugas')): ?>
                <?php echo e(Breadcrumbs::render('masyarakat.pengaduan.show',$pengaduan)); ?>

            <?php else: ?>
                <?php echo e(Breadcrumbs::render('admin.pengaduan.show',$pengaduan)); ?>

            <?php endif; ?>
        </div>
    </div>
    <div class="section-body">
       <div class="row">
           <div class="col-12">
               <div class="card">
                   <div class="card-header">
                       <h4>Detail Pengaduan</h4>
                   </div>
                   <div class="card-body">
                    <form>
                        <div class="form-group row mb-4">
                            <label for="judul_laporan" class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Judul Laporan</label>
                            <div class="col-sm-12 col-md-7">
                                <input type="text" id="judul_laporan" name="judul_laporan" class="form-control <?php $__errorArgs = ['judul_laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Judul Laporan Pengaduan" autocomplete="off" value="<?php echo e($pengaduan->judul_laporan); ?>" disabled>
                            </div>
                        </div>
                    <div class="form-group row mb-4">
                        <label for="isi_laporan" class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Isi Laporan</label>
                        <div class="col-sm-12 col-md-7">
                            <textarea id="isi_laporan" name="isi_laporan" class="form-control <?php $__errorArgs = ['isi_laporan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Isi Laporan Pengaduan" autocomplete="off" disabled><?php echo e($pengaduan->isi_laporan); ?></textarea>
                        </div>
                    </div>
                       <div class="form-group row mb-4">
                           <label for="foto" class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Foto</label>
                           <div class="col-sm-12 col-md-7">
                               <img src="<?php echo e(Storage::url('pengaduan/'.$pengaduan->foto)); ?>" alt="<?php echo e($pengaduan->foto); ?>" class="img-fluid" width="200">
                           </div>
                       </div>
                       <div class="form-group row mb-4">
                        <label for="status" class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Status</label>
                        <div class="col-sm-12 col-md-7">
                            <?php if($pengaduan->status == '0'): ?>
                            <p><span class="badge badge-primary">Ditinjau</span></p>
                           <?php elseif($pengaduan->status == 'proses'): ?>
                            <p><span class="badge badge-warning"><?php echo e(ucfirst($pengaduan->status)); ?></span></p>
                           <?php elseif($pengaduan->status == 'selesai'): ?>
                            <p><span class="badge badge-success"><?php echo e(ucfirst($pengaduan->status)); ?></span></p>
                           <?php endif; ?>
                        </div>
                    </div>
                    </form>
                   </div>
               </div>
           </div>
           <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Tanggapan</h4>
                </div>
                <div class="card-body">
                    <?php if($pengaduan->status == '0'): ?>
                    <strong>Harap bersabar, pengaduan masih ditinjau</strong>
                    <?php elseif($pengaduan->status == 'proses'): ?>
                    <strong>Pengaduan sudah ditinjau dan sedang diproses</strong>
                    <?php elseif($pengaduan->status == 'selesai'): ?>
                 <form>
                    <div class="form-group row mb-4">
                        <label for="pengaduan" class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Judul Laporan</label>
                        <div class="col-sm-12 col-md-7">
                           <select name="pengaduan" class="form-control" id="pengaduan" disabled>
                                   <option value="" selected><?php echo e($pengaduan->judul_laporan); ?></option>
                           </select>
                        </div>
                    </div>
                <div class="form-group row mb-4">
                    <label for="tanggapan" class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Tanggapan</label>
                    <div class="col-sm-12 col-md-7">
                        <textarea id="tanggapan" name="tanggapan" class="form-control" disabled><?php echo e($pengaduan->tanggapan->tanggapan); ?></textarea>
                    </div>
                </div>
                <div class="form-group row mb-4">
                    <label for="oleh" class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Ditanggapi Oleh</label>
                    <div class="col-sm-12 col-md-7">
                        <input type="text" id="oleh" name="oleh" class="form-control" value="<?php echo e($pengaduan->tanggapan->petugas->nama_petugas); ?>" disabled>
                    </div>
                </div>
                 </form>
                 <?php endif; ?>
                </div>
            </div>
        </div>
       </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\appm\resources\views/admin/pengaduan/show.blade.php ENDPATH**/ ?>