<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php if (isset($component)) { $__componentOriginal0ffb0a0d50d0f581dbd60338c0b56c81fed4e7d6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Head::class, []); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0ffb0a0d50d0f581dbd60338c0b56c81fed4e7d6)): ?>
<?php $component = $__componentOriginal0ffb0a0d50d0f581dbd60338c0b56c81fed4e7d6; ?>
<?php unset($__componentOriginal0ffb0a0d50d0f581dbd60338c0b56c81fed4e7d6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<head>

    <body>
        <div id="app">
            <section class="section">
                <div class="container mt-5">
                    <div class="row">
                        <div
                            class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
                            <div class="login-brand">
                              <strong>Aplikasi Pelaporan Pengaduan Masyarakat</strong>
                            </div>

                            <div class="card card-primary">
                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                            <?php echo $__env->yieldContent('page'); ?>
                            <div class="simple-footer">
                                Copyright &copy;
                                <?php echo e(date('Y')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </body>

</html>
<?php /**PATH D:\Project\appm\resources\views/layouts/auth.blade.php ENDPATH**/ ?>