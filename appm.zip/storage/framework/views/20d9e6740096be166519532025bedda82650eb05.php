<?php $__env->startSection('title','Petugas'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Petugas</h1>
            <div class="section-header-breadcrumb">
                <?php echo e(Breadcrumbs::render('admin.petugas')); ?>

            </div>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="text-primary">Petugas
                                <span>(<?php echo e($petugas->total()); ?>)</span>
                                <a href="<?php echo e(route('admin.petugas.create')); ?>" class="btn btn-primary">Tambah <i class="fas fa-plus"></i></a>
                            </h4>
                            <div class="card-header-form">
                                <form action=<?php echo e(route(request()->route()->getName())); ?>>
                                    <div class="input-group">
                                      <input type="text" class="form-control" placeholder="Cari" name="search" value="<?php echo e(request()->get('search')); ?>">
                                      <div class="input-group-btn">
                                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                      </div>
                                    </div>
                                  </form>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive table-invoice">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Nama</th>
                                            <th>Nama Pengguna</th>
                                            <th>Hak Akses</th>
                                            <th>Dibuat</th>
                                            <th>Diedit</th>
                                            <th>Aksi</th>
                                        </tr>
                                     </thead>
                                        <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($p->nama_petugas); ?></td>
                                            <td><?php echo e($p->username); ?></td>
                                            <td>
                                                <?php $__empty_2 = true; $__currentLoopData = $p->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                    <?php echo e(ucfirst($role->name)); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                   <?php echo '<i>NULL</i>'; ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e(\Carbon\Carbon::parse($p->created_at)->isoFormat('DD MMMM Y')); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($p->updated_at)->isoFormat('DD MMMM Y')); ?></td>
                                            <td>
                                                <a href="<?php if($p->id != Auth::id()): ?> <?php echo e(route('admin.petugas.edit',['petuga' => $p])); ?> <?php else: ?> '' <?php endif; ?>" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                                <?php if($p->id != Auth::id()): ?>
                                                <button class="btn btn-danger delete-confirm" data-action="<?php echo e(route('admin.petugas.destroy',$p)); ?>"><i class="fa fa-trash"></i></button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr class="text-center">
                                            <td colspan="5">Tidak Ada Data</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="paginate">
                                <?php echo e($petugas->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\appm\resources\views/admin/petugas/index.blade.php ENDPATH**/ ?>