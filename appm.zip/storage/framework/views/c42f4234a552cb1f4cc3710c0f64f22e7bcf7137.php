<?php $__env->startSection('title','Pengaduan'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Pengaduan</h1>
            <div class="section-header-breadcrumb">
                <?php if(!auth()->check() || ! auth()->user()->hasRole('admin|petugas')): ?>
                    <?php echo e(Breadcrumbs::render('masyarakat.pengaduan')); ?>

                <?php else: ?>
                    <?php echo e(Breadcrumbs::render('admin.pengaduan')); ?>

                <?php endif; ?>
            </div>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="text-primary">Pengaduan
                                <span>(<?php echo e($pengaduan->total()); ?>)</span>
                                <?php if(!auth()->check() || ! auth()->user()->hasRole('admin|petugas')): ?>
                                    <a href="<?php echo e(route('masyarakat.pengaduan.create')); ?>" class="btn btn-primary">Tambah <i class="fas fa-plus"></i></a>
                                <?php endif; ?>
                                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                <a href="<?php echo e(route('admin.pengaduan.pdf')); ?>" class="btn btn-danger">Cetak PDF <i class="fas fa-newspaper"></i></a>
                                <?php endif; ?>
                            </h4>
                            <div class="card-header-form">
                                <form action=<?php echo e(route(request()->route()->getName())); ?>>
                                    <div class="input-group">
                                      <input type="text" class="form-control" placeholder="Cari" name="cari" value="<?php echo e(request()->get('search')); ?>">
                                      <div class="input-group-btn">
                                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                                      </div>
                                    </div>
                                  </form>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive table-invoice">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Tanggal Pengaduan</th>
                                            <th>Diajukan Oleh</th>
                                            <th>Judul Laporan</th>
                                            <th>Isi Laporan</th>
                                            <th>Foto</th>
                                            <th>Status</th>
                                            <th>Diedit</th>
                                            <th>Aksi</th>
                                        </tr>
                                     </thead>
                                        <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e(\Carbon\Carbon::parse($p->tgl_pengaduan)->isoFormat('DD MMMM Y')); ?></td>
                                            <td><?php echo e($p->masyarakat->nama); ?></td>
                                            <td><?php echo e($p->judul_laporan); ?></td>
                                            <td><?php echo e(Str::limit($p->isi_laporan,100,'...')); ?></td>
                                            <td><img src="<?php echo e(Storage::url('pengaduan/'.$p->foto)); ?>" alt="<?php echo e($p->foto); ?>" width="50"></td>
                                            <td>
                                                <?php if($p->status == '0'): ?>
                                                <span class="badge badge-primary">Dalam Peninjauan</span>
                                                <?php elseif($p->status == 'proses'): ?>
                                                <span class="badge badge-warning">Dalam Proses</span>
                                                <?php elseif($p->status == 'selesai'): ?>
                                                <span class="badge badge-success">Selesai Diproses</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e(\Carbon\Carbon::parse($p->created_at)->isoFormat('DD MMMM Y')); ?></td>
                                            <td>
                                                <a href="<?php if(Auth::guard('web')->check()): ?> <?php echo e(route('admin.pengaduan.show',['pengaduan' => $p])); ?> <?php else: ?> <?php echo e(route('masyarakat.pengaduan.show',['pengaduan' => $p])); ?> <?php endif; ?>" class="btn btn-success"><i class="fa fa-eye"></i></a>
                                                <?php if(!$p->status == 'proses' || !$p->status == 'selesai'): ?>
                                                    <a href="<?php if(Auth::guard('web')->check()): ?> <?php echo e(route('admin.pengaduan.edit',['pengaduan' => $p])); ?> <?php else: ?> <?php echo e(route('masyarakat.pengaduan.edit',['pengaduan' => $p])); ?> <?php endif; ?>" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                                    <?php if(!auth()->check() || ! auth()->user()->hasRole('admin|petugas')): ?>
                                                    <button class="btn btn-danger delete-confirm" data-action="<?php echo e(route('masyarakat.pengaduan.destroy',$p)); ?>"><i class="fa fa-trash"></i></button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr class="text-center">
                                            <td colspan="8">Tidak Ada Data</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="paginate">
                                <?php echo e($pengaduan->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\appm\resources\views/admin/pengaduan/index.blade.php ENDPATH**/ ?>