
<!DOCTYPE html>
<html>
<head>
 <title>Tanggapan</title>
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Tanggal Tanggapan</th>
                <th>Judul Pengaduan</th>
                <th>Tanggapan</th>
                <th>Yang Menanggapi</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $data["tanggapan"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e(\Carbon\Carbon::parse($t->tgl_tanggapan)->isoFormat('DD MMMM Y')); ?></td>
                <td><?php echo e($t->pengaduan->judul_laporan); ?></td>
                <td><?php echo e($t->tanggapan); ?></td>
                <td><?php echo e($t->petugas->nama_petugas); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr class="text-center">
                <td colspan="4">Tidak Ada Data</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>

<?php /**PATH D:\Project\appm\resources\views/admin/tanggapan/pdf.blade.php ENDPATH**/ ?>