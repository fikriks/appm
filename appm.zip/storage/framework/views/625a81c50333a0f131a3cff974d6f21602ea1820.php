
<!DOCTYPE html>
<html>
<head>
 <title>Tanggapan</title>
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Tanggal Pengaduan</th>
                <th>Diajukan Oleh</th>
                <th>Judul Laporan</th>
                <th>Isi Laporan</th>
                <th>Foto</th>
                <th>Status</th>
            </tr>
         </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $data["pengaduan"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e(\Carbon\Carbon::parse($p->tgl_pengaduan)->isoFormat('DD MMMM Y')); ?></td>
                <td><?php echo e($p->masyarakat->nama); ?></td>
                <td><?php echo e($p->judul_laporan); ?></td>
                <td><?php echo e($p->isi_laporan); ?></td>
                <td><img src="<?php echo e(storage_path('app/public/pengaduan/'.$p->foto)); ?>" alt="<?php echo e($p->foto); ?>" width="50"></td>
                <td>
                    <?php if($p->status == '0'): ?>
                    <span class="badge badge-primary">Dalam Peninjauan</span>
                    <?php elseif($p->status == 'proses'): ?>
                    <span class="badge badge-warning">Dalam Proses</span>
                    <?php elseif($p->status == 'selesai'): ?>
                    <span class="badge badge-success">Selesai Diproses</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr class="text-center">
                <td colspan="6">Tidak Ada Data</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>

<?php /**PATH D:\Project\appm\resources\views/admin/pengaduan/pdf.blade.php ENDPATH**/ ?>