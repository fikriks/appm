<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1>Dashboard</h1>
        </div>
        <div class="section-body">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12">
                <div class="card card-statistic-2">
                <div class="card-icon shadow-primary bg-danger">
                    <i class="fas fa-suitcase"></i>
                </div>
                <div class="card-wrap">
                    <div class="card-header">
                    <h4>Total Pengaduan</h4>
                    </div>
                    <div class="card-body">
                    <?php echo e(count($pengaduanTotal)); ?>

                    </div>
                </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-12">
                <div class="card card-statistic-2">
                    <div class="card-icon shadow-primary bg-primary">
                    <i class="fas fa-glasses"></i>
                    </div>
                    <div class="card-wrap">
                    <div class="card-header">
                        <h4>Pengaduan Ditinjau</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e(count($pengaduanDitinjau)); ?>

                    </div>
                    </div>
                </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12">
                <div class="card card-statistic-2">
                    <div class="card-icon shadow-primary bg-warning">
                    <i class="fas fa-wrench"></i>
                    </div>
                    <div class="card-wrap">
                    <div class="card-header">
                        <h4>Pengaduan Diproses</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e(count($pengaduanDiproses)); ?>

                    </div>
                    </div>
                </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12">
                <div class="card card-statistic-2">
                    <div class="card-icon shadow-primary bg-success">
                    <i class="fas fa-briefcase"></i>
                    </div>
                    <div class="card-wrap">
                    <div class="card-header">
                        <h4>Pengaduan Selesai</h4>
                    </div>
                    <div class="card-body">
                        <?php echo e(count($pengaduanSelesai)); ?>

                    </div>
                    </div>
                </div>
                </div>
            </div>
            <?php if(!auth()->check() || ! auth()->user()->hasRole('admin|petugas')): ?>
                <div class="card">
                    <div class="card-body p-5">
                <p class="font-weight-bold h4">Mempunya pengaduan untuk pemerintahan kami? <br><br>Silahkan ajukan pengaduan anda <a href="<?php echo e(route('masyarakat.pengaduan.create')); ?>"><u>disini</u></a><br><br>Pengaduan anda sangat penting bagi kami, agar kami terus meningkatkan kinerja kami, terima kasih!!</p>
            </div>
        </div>
                <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\appm\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>